# Desi Cinema TV v1.5

Fire TV / Android TV WebView wrapper for DesiCinema.

v1.5 keeps D-pad cursor, scrolling and ad blocking, and adds a dedicated in-app player WebView so external movie-player windows can open without sending the user to a separate browser. Press Back to close the player window and return to DesiCinema.
