# DesiCinemaTV v1.4

Fire TV / Android TV WebView wrapper for DesiCinema.

Includes:
- D-pad cursor
- edge scrolling
- OK/center touch click
- fullscreen video support
- external pop-up blocking
- conservative ad/tracker host blocking

The ad blocker intentionally avoids broad URL-pattern blocking so video/CDN requests are less likely to be broken.
