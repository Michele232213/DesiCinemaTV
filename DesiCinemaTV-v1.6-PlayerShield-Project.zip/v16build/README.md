# DesiCinemaTV v1.6 Player Shield

Fire TV / Android TV WebView wrapper for DesiCinema.

Changes in v1.6:
- blocks new-window popups and common ad/tracker hosts
- keeps main navigation on DesiCinema
- allows direct media URLs
- modern Android TV user agent
- mixed-content and HTML5 video compatibility tweaks
- keeps D-pad cursor, scroll, OK-click and fullscreen support
