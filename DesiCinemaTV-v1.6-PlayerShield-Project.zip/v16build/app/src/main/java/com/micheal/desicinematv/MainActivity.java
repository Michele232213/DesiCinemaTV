package com.micheal.desicinematv;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Message;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://www.desicinema.org";
    private static final float MOVE_STEP = 42f;
    private static final int SCROLL_STEP = 260;
    private static final String TV_USER_AGENT = "Mozilla/5.0 (Linux; Android 11; AFTSSS Build/RS8141.1.0.1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/126.0.6478.122 Safari/537.36";

    private FrameLayout root;
    private WebView webView;
    private WebView playerWebView;
    private CursorView cursor;
    private float cursorX;
    private float cursorY;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        root = new FrameLayout(this);
        webView = new WebView(this);
        configureWebView(webView, false);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        cursor = new CursorView();
        FrameLayout.LayoutParams cursorParams = new FrameLayout.LayoutParams(dp(34), dp(40));
        root.addView(cursor, cursorParams);
        setContentView(root);

        root.post(() -> {
            cursorX = Math.max(10, (root.getWidth() - cursor.getWidth()) / 2f);
            cursorY = Math.max(10, (root.getHeight() - cursor.getHeight()) / 2f);
            renderCursor();
            webView.requestFocus();
        });

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        if (savedInstanceState == null) {
            webView.loadUrl(HOME_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void configureWebView(final WebView target, final boolean isPlayerWindow) {
        target.setBackgroundColor(Color.BLACK);
        target.setFocusable(true);
        target.setFocusableInTouchMode(true);

        WebSettings s = target.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(TV_USER_AGENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(true);
        }
        target.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        CookieManager.getInstance().setAcceptThirdPartyCookies(target, true);

        target.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl() != null ? request.getUrl().toString() : "";
                if (isAdOrTrackerUrl(url)) {
                    showBlockedMessage();
                    return true;
                }
                if (!request.isForMainFrame()) return false;
                if (isAllowedMainUrl(url) || isLikelyVideoUrl(url)) return false;
                // Keep third-party ad/redirect pages from replacing the movie page.
                showBlockedMessage();
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (isAdOrTrackerUrl(url)) {
                    showBlockedMessage();
                    return true;
                }
                if (isAllowedMainUrl(url) || isLikelyVideoUrl(url)) return false;
                showBlockedMessage();
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl() != null ? request.getUrl().toString() : "";
                if (isAdOrTrackerUrl(url)) {
                    return new WebResourceResponse("text/plain", "UTF-8", null);
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                if (isAdOrTrackerUrl(url)) {
                    return new WebResourceResponse("text/plain", "UTF-8", null);
                }
                return super.shouldInterceptRequest(view, url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.requestFocus();
                injectCompatibilityFixes(view);
                if (cursor != null) cursor.bringToFront();
            }
        });

        target.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                // DesiCinema embeds video in the page. New windows are overwhelmingly ad/pop-up redirects,
                // so block them and keep the current movie/player visible.
                showBlockedMessage();
                return false;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                root.addView(customView, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                webView.setVisibility(View.GONE);
                if (playerWebView != null) playerWebView.setVisibility(View.GONE);
                cursor.setVisibility(View.GONE);
                hideSystemUi();
            }

            @Override
            public void onHideCustomView() {
                exitFullscreenVideo();
            }
        });
    }

    private WebView activeWebView() {
        return playerWebView != null ? playerWebView : webView;
    }

    private boolean isAdOrTrackerUrl(String url) {
        if (url == null || url.isEmpty()) return false;
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase();

            String[] blockedHosts = new String[] {
                    "doubleclick.net", "googlesyndication.com", "googleadservices.com",
                    "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com",
                    "outbrain.com", "mgid.com", "adskeeper.com", "exoclick.com",
                    "exosrv.com", "popads.net", "popcash.net", "propellerads.com",
                    "onclicka.com", "trafficjunky.net", "zedo.com", "criteo.com",
                    "criteo.net", "juicyads.com", "adsterra.com", "monetag.com",
                    "onclickperformance.com", "pushground.com", "hilltopads.net",
                    "clickadu.com", "highperformanceformat.com",
                    "highperformancedisplayformat.com", "profitablegatecpm.com",
                    "effectivegatecpm.com", "histats.com", "cloudflareinsights.com"
            };

            for (String blocked : blockedHosts) {
                if (host.equals(blocked) || host.endsWith("." + blocked)) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean isLikelyVideoUrl(String url) {
        if (url == null) return false;
        String u = url.toLowerCase();
        return u.contains(".m3u8") || u.contains(".mp4") || u.contains(".webm") ||
                u.contains("manifest.mpd") || u.startsWith("blob:");
    }

    private void injectCompatibilityFixes(WebView view) {
        String js = "(function(){" +
                "try{" +
                "window.open=function(){return null;};" +
                "document.querySelectorAll('video').forEach(function(v){" +
                "v.setAttribute('playsinline','');v.setAttribute('webkit-playsinline','');" +
                "v.autoplay=false;v.controls=true;" +
                "});" +
                "document.querySelectorAll('a[target=\"_blank\"]').forEach(function(a){" +
                "a.addEventListener('click',function(e){" +
                "var h=(a.hostname||'').toLowerCase();" +
                "if(h && h.indexOf('desicinema.org')===-1){e.preventDefault();e.stopPropagation();}" +
                "},true);" +
                "});" +
                "}catch(e){}" +
                "})();";
        view.evaluateJavascript(js, null);
    }

    private boolean isAllowedMainUrl(String url) {
        if (url == null || url.startsWith("about:blank")) return true;
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase();
            return host.equals("desicinema.org") || host.equals("www.desicinema.org") || host.endsWith(".desicinema.org");
        } catch (Exception ignored) {
            return false;
        }
    }

    private void showBlockedMessage() {
        Toast.makeText(this, "Blocked an ad/pop-up", Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void renderCursor() {
        cursor.setX(cursorX);
        cursor.setY(cursorY);
        cursor.bringToFront();
    }

    private void moveCursor(float dx, float dy) {
        if (root.getWidth() == 0 || root.getHeight() == 0) return;

        float minX = 2f;
        float maxX = Math.max(minX, root.getWidth() - cursor.getWidth() - 2f);
        float minY = 2f;
        float maxY = Math.max(minY, root.getHeight() - cursor.getHeight() - 2f);
        WebView active = activeWebView();

        if (dy > 0 && cursorY >= maxY - MOVE_STEP) {
            active.scrollBy(0, SCROLL_STEP);
            cursorY = Math.min(maxY, cursorY);
        } else if (dy < 0 && cursorY <= minY + MOVE_STEP) {
            active.scrollBy(0, -SCROLL_STEP);
            cursorY = Math.max(minY, cursorY);
        } else {
            cursorX = Math.max(minX, Math.min(maxX, cursorX + dx));
            cursorY = Math.max(minY, Math.min(maxY, cursorY + dy));
        }
        renderCursor();
    }

    private void clickAtCursor() {
        WebView active = activeWebView();
        if (active == null) return;
        float x = cursorX + dp(4);
        float y = cursorY + dp(4);
        long now = SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0);
        MotionEvent up = MotionEvent.obtain(now, now + 80, MotionEvent.ACTION_UP, x, y, 0);
        active.dispatchTouchEvent(down);
        active.dispatchTouchEvent(up);
        down.recycle();
        up.recycle();
    }

    private void closePlayerWindow() {
        if (playerWebView == null) return;
        root.removeView(playerWebView);
        playerWebView.stopLoading();
        playerWebView.loadUrl("about:blank");
        playerWebView.destroy();
        playerWebView = null;
        webView.setVisibility(View.VISIBLE);
        webView.requestFocus();
        if (cursor != null) {
            cursor.setVisibility(View.VISIBLE);
            renderCursor();
        }
    }

    private void exitFullscreenVideo() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        webView.setVisibility(View.VISIBLE);
        if (playerWebView != null) playerWebView.setVisibility(View.VISIBLE);
        cursor.setVisibility(View.VISIBLE);
        if (customViewCallback != null) customViewCallback.onCustomViewHidden();
        customViewCallback = null;
        hideSystemUi();
        renderCursor();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            int key = event.getKeyCode();

            if (customView == null) {
                switch (key) {
                    case KeyEvent.KEYCODE_DPAD_LEFT:
                        moveCursor(-MOVE_STEP, 0);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_RIGHT:
                        moveCursor(MOVE_STEP, 0);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_UP:
                        moveCursor(0, -MOVE_STEP);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_DOWN:
                        moveCursor(0, MOVE_STEP);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_CENTER:
                    case KeyEvent.KEYCODE_ENTER:
                    case KeyEvent.KEYCODE_NUMPAD_ENTER:
                    case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                        clickAtCursor();
                        return true;
                }
            }

            if (key == KeyEvent.KEYCODE_BACK) {
                if (customView != null) {
                    exitFullscreenVideo();
                    return true;
                }
                if (playerWebView != null) {
                    closePlayerWindow();
                    return true;
                }
                if (webView.canGoBack()) {
                    webView.goBack();
                    return true;
                }
            }

            if (key == KeyEvent.KEYCODE_MENU) {
                activeWebView().reload();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        if (playerWebView != null) playerWebView.onResume();
        hideSystemUi();
        if (cursor != null && customView == null) {
            cursor.setVisibility(View.VISIBLE);
            renderCursor();
        }
    }

    @Override
    protected void onPause() {
        webView.onPause();
        if (playerWebView != null) playerWebView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        closePlayerWindow();
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    private class CursorView extends View {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        CursorView() {
            super(MainActivity.this);
            setFocusable(false);
            setClickable(false);
            fillPaint.setColor(Color.WHITE);
            fillPaint.setStyle(Paint.Style.FILL);
            strokePaint.setColor(Color.BLACK);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(2));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            path.reset();
            path.moveTo(dp(3), dp(2));
            path.lineTo(dp(3), h - dp(7));
            path.lineTo(dp(11), h - dp(15));
            path.lineTo(dp(17), h - dp(2));
            path.lineTo(dp(24), h - dp(6));
            path.lineTo(dp(18), h - dp(18));
            path.lineTo(w - dp(3), h - dp(18));
            path.close();
            canvas.drawPath(path, fillPaint);
            canvas.drawPath(path, strokePaint);
        }
    }
}
