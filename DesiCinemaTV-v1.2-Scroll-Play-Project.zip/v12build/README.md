# Desi Cinema TV v1.2

Fire TV / Android TV WebView wrapper for https://www.desicinema.org.

## v1.2 controls
- D-pad: moves a native on-screen cursor
- At top/bottom edge, Up/Down scrolls the page
- Center/OK: sends a real touch click to the WebView
- Play/Pause: also clicks at the cursor
- Back: browser back / exits fullscreen video
- Menu: reloads the page

This version uses native Android touch injection instead of JavaScript synthetic clicks for better compatibility with video players and iframes.
