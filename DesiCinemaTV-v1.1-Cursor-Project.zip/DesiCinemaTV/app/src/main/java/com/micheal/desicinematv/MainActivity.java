package com.micheal.desicinematv;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://www.desicinema.org";
    private WebView webView;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private static final String CURSOR_JS =
        "(function(){" +
        "if(window.__tvCursorReady)return;window.__tvCursorReady=true;" +
        "window.__tvX=Math.round(window.innerWidth/2);window.__tvY=Math.round(window.innerHeight/2);" +
        "var c=document.createElement('div');c.id='__tv_cursor';" +
        "c.style.cssText='position:fixed;left:0;top:0;width:26px;height:26px;z-index:2147483647;pointer-events:none;transform:translate(-3px,-3px);filter:drop-shadow(0 1px 2px #000);';" +
        "c.innerHTML='<svg width=\"26\" height=\"26\" viewBox=\"0 0 26 26\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M2 1 L2 21 L8 15 L12 24 L16 22 L12 13 L21 13 Z\" fill=\"white\" stroke=\"black\" stroke-width=\"2\"/></svg>';" +
        "document.documentElement.appendChild(c);" +
        "window.__tvRender=function(){c.style.left=window.__tvX+'px';c.style.top=window.__tvY+'px';};" +
        "window.__tvMove=function(dx,dy){window.__tvX=Math.max(4,Math.min(window.innerWidth-4,window.__tvX+dx));window.__tvY=Math.max(4,Math.min(window.innerHeight-4,window.__tvY+dy));window.__tvRender();" +
        "var e=document.elementFromPoint(window.__tvX,window.__tvY);if(e){try{e.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:window.__tvX,clientY:window.__tvY}));}catch(x){}}};" +
        "window.__tvClick=function(){var e=document.elementFromPoint(window.__tvX,window.__tvY);if(!e)return;" +
        "try{e.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window,clientX:window.__tvX,clientY:window.__tvY}));" +
        "e.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window,clientX:window.__tvX,clientY:window.__tvY}));" +
        "e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window,clientX:window.__tvX,clientY:window.__tvY}));}catch(x){try{e.click();}catch(y){}}};" +
        "window.__tvRender();" +
        "})();";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF000000);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.requestFocus();
                installCursor();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                ViewGroup decor = (ViewGroup) getWindow().getDecorView();
                decor.addView(customView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                webView.setVisibility(View.GONE);
                hideSystemUi();
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                ViewGroup decor = (ViewGroup) getWindow().getDecorView();
                decor.removeView(customView);
                customView = null;
                webView.setVisibility(View.VISIBLE);
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customViewCallback = null;
                hideSystemUi();
                installCursor();
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl(HOME_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void installCursor() {
        if (webView != null) webView.evaluateJavascript(CURSOR_JS, null);
    }

    private void cursorMove(int dx, int dy) {
        if (webView != null) webView.evaluateJavascript("if(window.__tvMove){window.__tvMove(" + dx + "," + dy + ");}", null);
    }

    private void cursorClick() {
        if (webView != null) webView.evaluateJavascript("if(window.__tvClick){window.__tvClick();}", null);
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            int key = event.getKeyCode();

            if (customView == null) {
                switch (key) {
                    case KeyEvent.KEYCODE_DPAD_LEFT:
                        cursorMove(-38, 0);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_RIGHT:
                        cursorMove(38, 0);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_UP:
                        cursorMove(0, -38);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_DOWN:
                        cursorMove(0, 38);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_CENTER:
                    case KeyEvent.KEYCODE_ENTER:
                    case KeyEvent.KEYCODE_NUMPAD_ENTER:
                        cursorClick();
                        return true;
                }
            }

            if (key == KeyEvent.KEYCODE_BACK) {
                if (customView != null) {
                    if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                    return true;
                }
                if (webView.canGoBack()) {
                    webView.goBack();
                    return true;
                }
            }
            if (key == KeyEvent.KEYCODE_MENU) {
                webView.reload();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        hideSystemUi();
        installCursor();
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
