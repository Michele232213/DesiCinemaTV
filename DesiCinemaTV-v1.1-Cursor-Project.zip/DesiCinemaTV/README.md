# Desi Cinema TV

Android TV / Fire TV WebView wrapper for https://www.desicinema.org

Features:
- Android TV and Fire TV launcher support
- Landscape fullscreen UI
- D-pad / remote focus support
- Back button navigates browser history
- Fullscreen HTML5 video support
- JavaScript, DOM storage, cookies and mixed content enabled
- Keeps screen awake while watching

## Build locally
Open the project in Android Studio and build the `app` module, or run Gradle `:app:assembleDebug` with Android SDK 35 installed.

## GitHub build
Push this project to GitHub. The included Actions workflow builds the APK and uploads it as `DesiCinemaTV-debug-apk`.
